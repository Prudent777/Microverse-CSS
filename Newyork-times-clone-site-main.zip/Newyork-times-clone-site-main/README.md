![](https://img.shields.io/badge/Microverse-blueviolet)

# Project 1 - New York Times Article Copy

> This is the Project 1 in the Microverse course

### View in browser
[Link](https://tanzila-abedin.github.io/Newyork-times-clone-site/.)

### Screenshot
![Screenshot](images/Screenshot.png)

## Built With

- HTML
- CSS

## Authors

👤 **Tanzila Abedin**


## Contributing

Contributions, issues, and feature requests are welcome!

Feel free to check the [issues page](issues/).

## 📝 License

This project is [MIT](LICENSE) licensed.
